import java.util.*;

public class GD<T> implements Grafo<T> {
    private Map<T, List<T>> listaDeAdyacencia;

    public GD() {
        listaDeAdyacencia = new HashMap<>();
    }

    /**
     * Añade un vértice al grafo <p>Agrega un nuevo elemento al hashMap donde vertex es el vértice y la lista corresponde
     * a los vértices con los que tiene conexión dirigida</p>
     */
    @Override
    public void addVertex(T vertex) {
        listaDeAdyacencia.putIfAbsent(vertex, new ArrayList<>());
    }

    /**
     * Agrega una relación unidireccional entre dos nodos <p>Recibe dos vértices 1 y 2. Si no existen en el grafo, los
     * crea. Luego añade el vértice2 a la lista del vértice1</p>
     */
    @Override
    public void addEdge(T vertex1, T vertex2) {
        listaDeAdyacencia.putIfAbsent(vertex1, new ArrayList<>());
        listaDeAdyacencia.putIfAbsent(vertex2, new ArrayList<>());
        listaDeAdyacencia.get(vertex1).add(vertex2); // Solo agregar una dirección
    }

    /**
     * Retorna la lista de vértices asociados a vertex (retorna los vértices con los que se relaciona unidireccionalmente
     * con vertex) <p>El método getOrDefault del hashMap nos retorna la lista (value) del vertex (key)</p>
     */
    @Override
    public List<T> getNeighbors(T vertex) {
        return listaDeAdyacencia.getOrDefault(vertex, new ArrayList<>());
    }

    /**
     * Imprime en consola los vértices y sus aristas
     */
    @Override
    public void printGraph(String nombre) {
        System.out.println("Grafo: "+nombre);
        for (Map.Entry<T, List<T>> entry : listaDeAdyacencia.entrySet()) {
            System.out.print("Vértice " + entry.getKey() + ": ");
            for (T neighbor : entry.getValue()) {
                System.out.print(neighbor + " ");
            }
            System.out.println();
        }
    }

    /**
     * Elimina un vértice del grafo <p>Remueve del hashMap la key vertex. Luego recorre todos los value valores del hashMap
     * y elimina los que tengan como valor vertex</p>
     */
    @Override
    public void removeVertex(T vertex) {
        listaDeAdyacencia.remove(vertex);
        for (List<T> neighbors : listaDeAdyacencia.values()) {
            neighbors.remove(vertex);
        }
    }

    /**
     * Elimina una arista <p>Recibe dos vértices. Primero recoge la lista de vértices del vértice1. Luego, si es que
     * la lista es no nula, procede a eliminar el valor igual al del vértice2</p>
     */
    @Override
    public void removeEdge(T vertex1, T vertex2) {
        List<T> eV1 = listaDeAdyacencia.get(vertex1);
        if (eV1 != null) eV1.remove(vertex2);
    }

    /**Calcula la cantidad de accesos para llegar de un vector a otro <p>Esta versión la he creado yo, pero da error cuando
     * no existe un camino entre el vértice1 y el vértice2</p>*/
    public int myAccessTo(T vertex1, T vertex2) {
        // desde vértice uno, acceder a los vectores que tenga relacion
        // preguntar si son el vertex2. Sino, preguntar por sus vectores relacionados
        List<T> vecinos = getNeighbors(vertex1);
        if (vecinos != null){
            for (T key : vecinos){ // Recorre la lista del vertex
                if(key == vertex2) return 1;
                return 1+myAccessTo(key, vertex2);
            }
        }
        return -1;
    }

    /**Calcula la cantidad de accesos para llegar de un vector a otro <p>Este código ha sido generado por ChatGPT</p>*/
    public int accessTo(T vertex1, T vertex2) {
        if (vertex1.equals(vertex2)) return 0;

        Queue<T> queue = new LinkedList<>();
        Map<T, Integer> distances = new HashMap<>();

        queue.add(vertex1);
        distances.put(vertex1, 0);

        while (!queue.isEmpty()) {
            T current = queue.poll();
            int currentDistance = distances.get(current);

            for (T neighbor : getNeighbors(current)) {
                if (!distances.containsKey(neighbor)) {
                    distances.put(neighbor, currentDistance + 1);
                    queue.add(neighbor);

                    if (neighbor.equals(vertex2)) {
                        return distances.get(neighbor);
                    }
                }
            }
        }

        return -1; // No hay camino desde vertex1 a vertex2
    }

    public void printAccessToAll(T inicio) {
        System.out.println("\nAcceso desde "+inicio+" a todas las páginas");
        for (T vertex : listaDeAdyacencia.keySet()) {
            int access = accessTo(inicio, vertex);
            System.out.println("Accesos desde " + inicio + " a " + vertex + ": " + access);
        }
    }
}
