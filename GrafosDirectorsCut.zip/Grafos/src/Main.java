public class Main {
    public static void main(String[] args) {
        // Problema de sitios web anexados
        GD web = new GD();
        web.addVertex("P1");
        web.addVertex("P2");
        web.addVertex("P3");
        web.addVertex("P4");
        web.addVertex("P5");

        web.addEdge("P1", "P2");
        web.addEdge("P1", "P4");
        web.addEdge("P2", "P3");
        web.addEdge("P3", "P1");
        web.addEdge("P4", "P3");
        web.addEdge("P5", "P4");
        web.addEdge("P5", "P1");

        web.printGraph("web");
        web.printAccessToAll("P1");
    }
}
