import java.util.List;

public interface Grafo<T> {
    void addVertex(T vertex);
    void addEdge(T vertex1, T vertex2);
    List<T> getNeighbors(T vertex);
    void printGraph(String nombre);
    void removeVertex(T vertex);
    void removeEdge(T vertex1, T vertex2);
}
